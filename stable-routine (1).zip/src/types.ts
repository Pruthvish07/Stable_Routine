export type Theme = 'light' | 'grey' | 'dark';

export interface Task {
  id: string;
  title: string;
  completed: boolean;
  category?: string;
}

export interface DailyScore {
  date: string; // ISO date string
  score: number;
}

export interface AppState {
  tasks: Task[];
  scores: DailyScore[];
  streak: number;
  theme: Theme;
  lastCompletedDate: string | null;
}
