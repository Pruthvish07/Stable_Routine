import { Task } from './types';

export const DEFAULT_ROUTINE: Task[] = [
  { id: '1', title: '7-hour Sleep', completed: false, category: 'Health' },
  { id: '2', title: '4-hour Deep Work', completed: false, category: 'Productivity' },
  { id: '3', title: '1-hour Physical Activity', completed: false, category: 'Health' },
  { id: '4', title: '30-minute Planning', completed: false, category: 'Productivity' },
];

export const STORAGE_KEY = 'stable_routine_data';
