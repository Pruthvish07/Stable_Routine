import * as React from 'react';
import { Sun, Moon, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Theme } from '@/src/types';

interface ThemeSwitcherProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

export function ThemeSwitcher({ theme, setTheme }: ThemeSwitcherProps) {
  return (
    <div className="flex items-center gap-2 bg-muted p-1 rounded-lg">
      <Button
        variant={theme === 'light' ? 'default' : 'ghost'}
        size="icon"
        onClick={() => setTheme('light')}
        className="h-8 w-8"
        title="Light Mode"
      >
        <Sun className="h-4 w-4" />
      </Button>
      <Button
        variant={theme === 'grey' ? 'default' : 'ghost'}
        size="icon"
        onClick={() => setTheme('grey')}
        className="h-8 w-8"
        title="Grey Mode"
      >
        <Palette className="h-4 w-4" />
      </Button>
      <Button
        variant={theme === 'dark' ? 'default' : 'ghost'}
        size="icon"
        onClick={() => setTheme('dark')}
        className="h-8 w-8"
        title="Dark Mode"
      >
        <Moon className="h-4 w-4" />
      </Button>
    </div>
  );
}
