import * as React from 'react';
import { ThemeSwitcher } from './ThemeSwitcher';
import { Theme } from '@/src/types';
import { Activity } from 'lucide-react';

interface HeaderProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

export function Header({ theme, setTheme }: HeaderProps) {
  return (
    <header className="flex items-center justify-between py-6 mb-8 border-b">
      <div className="flex items-center gap-2">
        <div className="bg-primary p-2 rounded-xl">
          <Activity className="text-primary-foreground h-6 w-6" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Stable Routine</h1>
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest">
            Consistency is key
          </p>
        </div>
      </div>
      <ThemeSwitcher theme={theme} setTheme={setTheme} />
    </header>
  );
}
