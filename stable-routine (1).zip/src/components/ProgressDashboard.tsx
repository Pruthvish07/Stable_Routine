import * as React from 'react';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Flame, Target, CheckCircle2 } from 'lucide-react';

interface ProgressDashboardProps {
  score: number;
  streak: number;
  completedTasks: number;
  totalTasks: number;
}

export function ProgressDashboard({ score, streak, completedTasks, totalTasks }: ProgressDashboardProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <Card className="bg-primary text-primary-foreground border-none shadow-lg overflow-hidden relative">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Target size={80} />
        </div>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium opacity-80">Today's Score</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold mb-2">{Math.round(score)}%</div>
          <Progress value={score} className="h-2 bg-primary-foreground/20" />
        </CardContent>
      </Card>

      <Card className="shadow-sm border-none bg-card">
        <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-sm font-medium text-muted-foreground">Current Streak</CardTitle>
          <Flame className="h-4 w-4 text-orange-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{streak} Days</div>
          <p className="text-xs text-muted-foreground mt-1">
            Keep it up! (80%+ goal)
          </p>
        </CardContent>
      </Card>

      <Card className="shadow-sm border-none bg-card">
        <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-sm font-medium text-muted-foreground">Tasks Done</CardTitle>
          <CheckCircle2 className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold">{completedTasks}/{totalTasks}</div>
          <p className="text-xs text-muted-foreground mt-1">
            {totalTasks - completedTasks} remaining for today
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
