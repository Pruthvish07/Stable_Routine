import * as React from 'react';
import { Header } from './components/Header';
import { ProgressDashboard } from './components/ProgressDashboard';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { TaskCard } from './components/TaskCard';
import { TaskForm } from './components/TaskForm';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Task, DailyScore, Theme, AppState } from './types';
import { DEFAULT_ROUTINE, STORAGE_KEY } from './constants';
import { AnimatePresence } from 'motion/react';
import { format, isSameDay, subDays, parseISO } from 'date-fns';

export default function App() {
  const [state, setState] = React.useState<AppState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Check if we need to reset tasks for a new day
        const today = format(new Date(), 'yyyy-MM-dd');
        const lastDate = parsed.lastCompletedDate;
        
        if (lastDate !== today) {
          // It's a new day! Save yesterday's score if not already saved
          return {
            ...parsed,
            tasks: parsed.tasks.map((t: Task) => ({ ...t, completed: false })),
            lastCompletedDate: today,
          };
        }
        return parsed;
      } catch (e) {
        console.error('Failed to parse saved state', e);
      }
    }
    return {
      tasks: DEFAULT_ROUTINE,
      scores: [],
      streak: 0,
      theme: 'light',
      lastCompletedDate: format(new Date(), 'yyyy-MM-dd'),
    };
  });

  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [editingTask, setEditingTask] = React.useState<Task | null>(null);

  // Persistence
  React.useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    // Apply theme to document
    document.documentElement.classList.remove('light', 'grey', 'dark');
    document.documentElement.classList.add(state.theme);
  }, [state]);

  const todayScore = React.useMemo(() => {
    if (state.tasks.length === 0) return 0;
    const completed = state.tasks.filter((t) => t.completed).length;
    return (completed / state.tasks.length) * 100;
  }, [state.tasks]);

  // Update scores and streak
  React.useEffect(() => {
    const today = format(new Date(), 'yyyy-MM-dd');
    const existingScoreIndex = state.scores.findIndex((s) => s.date === today);
    
    let newScores = [...state.scores];
    if (existingScoreIndex >= 0) {
      newScores[existingScoreIndex] = { date: today, score: todayScore };
    } else {
      newScores.push({ date: today, score: todayScore });
    }

    // Keep only last 30 days of history
    if (newScores.length > 30) {
      newScores = newScores.slice(-30);
    }

    // Calculate streak
    let currentStreak = 0;
    const sortedScores = [...newScores].sort((a, b) => b.date.localeCompare(a.date));
    
    // Check if we have a score for today or yesterday to start the streak
    const yesterday = format(subDays(new Date(), 1), 'yyyy-MM-dd');
    let checkDate = today;
    
    // If today's score is < 80, we might still have a streak from yesterday
    if (todayScore < 80) {
      checkDate = yesterday;
    }

    for (let i = 0; i < 30; i++) {
      const d = format(subDays(new Date(checkDate), i), 'yyyy-MM-dd');
      const dayScore = newScores.find(s => s.date === d);
      if (dayScore && dayScore.score >= 80) {
        currentStreak++;
      } else {
        break;
      }
    }

    if (currentStreak !== state.streak || JSON.stringify(newScores) !== JSON.stringify(state.scores)) {
      setState(prev => ({ ...prev, scores: newScores, streak: currentStreak }));
    }
  }, [todayScore]);

  const handleToggleTask = (id: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      ),
    }));
  };

  const handleDeleteTask = (id: string) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== id),
    }));
  };

  const handleAddOrEditTask = (title: string) => {
    if (editingTask) {
      setState((prev) => ({
        ...prev,
        tasks: prev.tasks.map((t) =>
          t.id === editingTask.id ? { ...t, title } : t
        ),
      }));
      setEditingTask(null);
    } else {
      const newTask: Task = {
        id: Math.random().toString(36).substr(2, 9),
        title,
        completed: false,
      };
      setState((prev) => ({
        ...prev,
        tasks: [...prev.tasks, newTask],
      }));
    }
  };

  const openEditForm = (task: Task) => {
    setEditingTask(task);
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <Header 
          theme={state.theme} 
          setTheme={(theme) => setState(prev => ({ ...prev, theme }))} 
        />

        <main>
          <ProgressDashboard 
            score={todayScore} 
            streak={state.streak}
            completedTasks={state.tasks.filter(t => t.completed).length}
            totalTasks={state.tasks.length}
          />

          <AnalyticsCharts 
            scores={state.scores}
            completed={state.tasks.filter(t => t.completed).length}
            pending={state.tasks.filter(t => !t.completed).length}
          />

          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">Daily Routine</h2>
            <Button onClick={() => setIsFormOpen(true)} size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              Add Task
            </Button>
          </div>

          <div className="grid gap-3">
            <AnimatePresence mode="popLayout">
              {state.tasks.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onToggle={handleToggleTask}
                  onDelete={handleDeleteTask}
                  onEdit={openEditForm}
                />
              ))}
            </AnimatePresence>
            
            {state.tasks.length === 0 && (
              <div className="text-center py-12 bg-muted/30 rounded-2xl border-2 border-dashed">
                <p className="text-muted-foreground">No tasks for today. Add one to get started!</p>
              </div>
            )}
          </div>
        </main>

        <TaskForm
          isOpen={isFormOpen}
          onClose={() => {
            setIsFormOpen(false);
            setEditingTask(null);
          }}
          onSubmit={handleAddOrEditTask}
          initialTask={editingTask}
        />
      </div>
    </div>
  );
}
